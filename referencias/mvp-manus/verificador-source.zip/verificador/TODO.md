# Critérios do MVP

- [x] A página exibe VERIFICA CIDADÃO, o slogan “Antes de acreditar. Antes de compartilhar. Verifique.”, uma área grande com “O que você deseja verificar?” e o botão “VERIFICAR INFORMAÇÃO”.
- [x] O usuário consegue colar texto, afirmação ou URL de notícia pública; o fluxo não oferece análise de imagem, PDF ou documentos.
- [x] Ao verificar, o sistema identifica uma afirmação principal, consulta aproximadamente três fontes públicas, compara o conteúdo e retorna exatamente uma das cinco classificações solicitadas.
- [x] O resultado mostra explicação curta, de no máximo três parágrafos, de 1 a 3 fontes com título e link e o aviso informativo obrigatório.
- [x] A interface é predominantemente branca, institucional, responsiva e mantém a regra de segurança: não transformar indício em acusação.
