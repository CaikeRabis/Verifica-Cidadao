import {
  AlertCircle,
  ArrowUpRight,
  Check,
  CheckCircle2,
  ExternalLink,
  FileText,
  Link2,
  Loader2,
  Search,
  ShieldCheck,
} from "lucide-react";
import { FormEvent, useState } from "react";

type Classification =
  | "🟢 CONFIRMADA"
  | "🟡 PARCIALMENTE CONFIRMADA"
  | "🟠 SEM EVIDÊNCIAS SUFICIENTES"
  | "🔴 CONTRADITA PELAS FONTES CONSULTADAS"
  | "⚪ NECESSITA DE ANÁLISE HUMANA";

type Source = {
  title: string;
  url: string;
  domain?: string;
  excerpt?: string;
};

type VerificationResult = {
  claim: string;
  classification: Classification;
  explanation: string;
  sources: Source[];
  analyzedAt: string;
};

const CLASSIFICATION_STYLES: Record<Classification, string> = {
  "🟢 CONFIRMADA": "result-confirmed",
  "🟡 PARCIALMENTE CONFIRMADA": "result-partial",
  "🟠 SEM EVIDÊNCIAS SUFICIENTES": "result-uncertain",
  "🔴 CONTRADITA PELAS FONTES CONSULTADAS": "result-contradicted",
  "⚪ NECESSITA DE ANÁLISE HUMANA": "result-human",
};

function BrandMark() {
  return (
    <div className="brand-mark" aria-hidden="true">
      <div className="brand-mark-sheet" />
      <div className="brand-mark-lens"><Search size={23} strokeWidth={2.8} /></div>
      <div className="brand-mark-check"><Check size={19} strokeWidth={3.2} /></div>
    </div>
  );
}

function formatDate(value: string) {
  try {
    return new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value));
  } catch {
    return value;
  }
}

export default function Home() {
  const [input, setInput] = useState("");
  const [result, setResult] = useState<VerificationResult | null>(null);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const trimmedInput = input.trim();
    if (trimmedInput.length < 8) {
      setError("Cole uma afirmação, notícia ou URL para começar a verificação.");
      setResult(null);
      return;
    }

    setIsLoading(true);
    setError("");
    setResult(null);
    try {
      const response = await fetch("/api/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ input: trimmedInput }),
      });
      const payload = (await response.json()) as VerificationResult | { error?: string };
      if (!response.ok) throw new Error("error" in payload ? payload.error : "Não foi possível realizar a verificação.");
      setResult(payload as VerificationResult);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Não foi possível realizar a verificação agora.");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="app-shell">
      <div className="top-ribbon" />
      <header className="site-header">
        <a className="brand" href="/" aria-label="Verifica Cidadão — página inicial">
          <BrandMark />
          <span className="brand-wordmark"><strong>VERIFICA</strong><b>CIDADÃO</b></span>
        </a>
        <div className="header-note"><ShieldCheck size={17} /> informação confiável para todos</div>
      </header>

      <main className="main-content">
        <section className="hero-section" aria-labelledby="hero-title">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> VERIFICAÇÃO CIDADÃ</div>
            <h1 id="hero-title">Antes de acreditar.<br />Antes de compartilhar.<br /><span>Verifique.</span></h1>
            <p className="hero-description">Consulte uma afirmação, notícia ou link e veja o que fontes públicas e confiáveis indicam.</p>
          </div>
          <div className="hero-symbol" aria-hidden="true">
            <div className="symbol-card symbol-card-back" />
            <div className="symbol-card symbol-card-front"><FileText size={32} /></div>
            <div className="symbol-lens"><Search size={45} strokeWidth={2.5} /></div>
            <div className="symbol-check"><Check size={29} strokeWidth={3.5} /></div>
          </div>
        </section>

        <section className="verify-panel" aria-label="Área de verificação">
          <form onSubmit={handleSubmit}>
            <label htmlFor="verification-input">O que você deseja verificar?</label>
            <div className="input-wrap">
              <textarea
                id="verification-input"
                value={input}
                onChange={event => setInput(event.target.value)}
                placeholder="Cole aqui uma notícia, afirmação ou URL pública..."
                rows={5}
                maxLength={12000}
                disabled={isLoading}
              />
              <div className="input-hint"><span><Link2 size={14} /> Texto ou URL de notícia aberta</span><span>{input.length}/12.000</span></div>
            </div>
            <div className="form-actions">
              <p>Usaremos até 3 fontes públicas. A análise é informativa.</p>
              <button className="primary-button" type="submit" disabled={isLoading}>
                {isLoading ? <><Loader2 className="spin" size={18} /> Verificando...</> : <>Verificar informação <ArrowUpRight size={18} /></>}
              </button>
            </div>
          </form>
        </section>

        {error && <div className="feedback feedback-error" role="alert"><AlertCircle size={19} /><span>{error}</span></div>}

        {isLoading && (
          <section className="loading-card" aria-live="polite">
            <div className="loading-icon"><Search size={22} /></div>
            <div><strong>Conferindo a informação</strong><p>Buscando poucas fontes públicas e comparando os dados...</p></div>
          </section>
        )}

        {result && !isLoading && (
          <section className="result-section" aria-live="polite">
            <div className="result-heading"><div><div className="eyebrow"><span className="eyebrow-line" /> RESULTADO DA VERIFICAÇÃO</div><h2>O que encontramos</h2></div><span className="result-date">Analisado em {formatDate(result.analyzedAt)}</span></div>
            <article className="result-card">
              <div className={`classification ${CLASSIFICATION_STYLES[result.classification]}`}><CheckCircle2 size={21} /><span>{result.classification}</span></div>
              <div className="result-block"><span className="result-label">Afirmação analisada</span><p className="claim">“{result.claim}”</p></div>
              <div className="result-block explanation-block"><span className="result-label">Por que chegamos a essa conclusão?</span><div className="explanation">{result.explanation.split(/\n{2,}/).map((paragraph, index) => <p key={`${paragraph}-${index}`}>{paragraph}</p>)}</div></div>
            </article>

            <div className="sources-header"><div><span className="result-label">Fontes consultadas</span><p>Referências públicas usadas nesta análise</p></div><span className="source-count">{result.sources.length}/3 fontes</span></div>
            <div className="sources-list">
              {result.sources.length > 0 ? result.sources.map((source, index) => <a className="source-card" href={source.url} target="_blank" rel="noreferrer" key={`${source.url}-${index}`}><div className="source-number">0{index + 1}</div><div className="source-content"><strong>{source.title}</strong><span>{source.domain || new URL(source.url).hostname.replace(/^www\./, "")}</span>{source.excerpt && <p>{source.excerpt}</p>}</div><ExternalLink size={17} /></a>) : <div className="empty-sources">Não encontramos fontes públicas suficientes para esta consulta.</div>}
            </div>

            <div className="notice"><AlertCircle size={18} /><p>Esta é uma análise automatizada de caráter informativo. O VERIFICA CIDADÃO não substitui jornalistas, especialistas, autoridades públicas ou órgãos de controle. Em situações sensíveis, consulte as fontes originais e os órgãos competentes.</p></div>
          </section>
        )}

        {!result && !isLoading && !error && <div className="trust-strip"><span><ShieldCheck size={18} /> Sem cadastro</span><span><CheckCircle2 size={18} /> Fontes visíveis</span><span><Search size={18} /> Consulta limitada</span></div>}
      </main>

      <footer className="site-footer"><div className="footer-brand"><BrandMark /><span>VERIFICA CIDADÃO</span></div><p>Tecnologia para informação, transparência e cidadania.</p><span className="footer-rule" /></footer>
    </div>
  );
}
