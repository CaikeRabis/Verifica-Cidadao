# VERIFICA CIDADÃO — plano do MVP

## Escopo
Uma página pública, sem login e sem banco, recebe texto, afirmação ou URL pública. O servidor extrai a página quando houver URL, busca no máximo três resultados públicos, envia apenas esse contexto para uma análise estruturada e devolve afirmação, classificação, explicação e fontes.

## Implementação
- Frontend React em `client/src/pages/Home.tsx` e `client/src/index.css`.
- Endpoint Express `POST /api/verify` em `server/verify.ts`.
- Busca simples via DuckDuckGo HTML; URL pública é baixada com limite de tamanho e tempo.
- Uma chamada curta ao LLM gerenciado apenas por solicitação, com saída JSON e classificação fechada.
- Sem persistência, autenticação, uploads, imagem, PDF, painel ou módulos extras.
- Manifesto de rotas em `public/manus-routes.json`.

## Design baseado no manual
- **Movimento:** institucional contemporâneo, com clareza editorial e sinais de serviço público digital.
- **Princípios:** confiança sem excesso visual; hierarquia direta; acessibilidade; transparência sobre limites.
- **Cores:** azul principal `#0B4EA2` para confiança e segurança; verde `#19A866` para confirmação; amarelo `#F3CA31` para atenção; cinza grafite `#404A57` para leitura; branco e cinza claro para espaço e legibilidade.
- **Layout:** coluna editorial ampla, entrada em destaque e resultado surgindo logo abaixo; sem dashboard ou grade complexa.
- **Assinaturas:** marca-lupa com check, filetes coloridos azul-amarelo-verde e cartões arredondados de resultado.
- **Interação:** botão primário único; estados de carregamento, erro e resultado explícitos; fontes sempre visíveis.
- **Animação:** transições curtas e discretas; sem movimento decorativo que distraia da leitura.
- **Tipografia:** títulos em peso forte, textos em sans-serif de alta legibilidade, com contraste amplo e corpo confortável.
- **Essência:** uma verificação pública, simples e responsável antes do compartilhamento; confiável, clara e cidadã.
- **Voz:** direta, acolhedora e cuidadosa. Exemplos: “Cole a informação. Nós começamos a conferir.” / “Fontes visíveis para você formar sua própria opinião.”
- **Marca:** wordmark em duas linhas com “VERIFICA” azul e “CIDADÃO” verde; ícone de lupa com check representa investigação e confirmação.

## Estrutura
- `client/src/pages/Home.tsx`: entrada, estados e card de resultado.
- `client/src/index.css`: identidade visual responsiva.
- `server/verify.ts`: coleta limitada, busca, análise e proteção de linguagem.
- `server/_core/index.ts`: registro do endpoint.
- `public/manus-routes.json`: rota pública única.
