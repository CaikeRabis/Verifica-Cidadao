import type { Express, Request, Response } from "express";
import { invokeLLM } from "./_core/llm";

type Source = { title: string; url: string; domain: string; excerpt: string };

const CLASSIFICATIONS = [
  "🟢 CONFIRMADA",
  "🟡 PARCIALMENTE CONFIRMADA",
  "🟠 SEM EVIDÊNCIAS SUFICIENTES",
  "🔴 CONTRADITA PELAS FONTES CONSULTADAS",
  "⚪ NECESSITA DE ANÁLISE HUMANA",
] as const;

const ANALYSIS_SCHEMA = {
  name: "verification_result",
  strict: true,
  schema: {
    type: "object",
    additionalProperties: false,
    required: ["claim", "classification", "explanation"],
    properties: {
      claim: { type: "string" },
      classification: { type: "string", enum: [...CLASSIFICATIONS] },
      explanation: { type: "string" },
    },
  },
};

function decodeHtml(value: string) {
  return value
    .replace(/<[^>]*>/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#x27;|&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)))
    .replace(/\s+/g, " ")
    .trim();
}

function cleanText(html: string) {
  return decodeHtml(
    html
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<nav[\s\S]*?<\/nav>/gi, " ")
      .replace(/<header[\s\S]*?<\/header>/gi, " ")
      .replace(/<footer[\s\S]*?<\/footer>/gi, " ")
  ).slice(0, 10000);
}

function titleFromHtml(html: string) {
  const match = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return match ? decodeHtml(match[1]).slice(0, 180) : "Notícia pública";
}

function isPublicUrl(value: string) {
  try {
    const url = new URL(value);
    if (!(url.protocol === "http:" || url.protocol === "https:")) return false;
    const host = url.hostname.toLowerCase();
    return !(
      host === "localhost" ||
      host === "::1" ||
      host === "0.0.0.0" ||
      host.startsWith("127.") ||
      host.startsWith("10.") ||
      host.startsWith("192.168.") ||
      /^172\.(1[6-9]|2\d|3[0-1])\./.test(host)
    );
  } catch {
    return false;
  }
}

async function fetchWithTimeout(url: string) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 7000);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { "User-Agent": "VerificaCidadaoMVP/1.0 (informational checker)" },
      redirect: "follow",
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const contentType = response.headers.get("content-type") || "";
    if (!contentType.includes("text/html") && !contentType.includes("text/plain")) throw new Error("Formato não suportado");
    const text = await response.text();
    return text.slice(0, 1_000_000);
  } finally {
    clearTimeout(timer);
  }
}

function resolveSearchUrl(rawUrl: string) {
  const decoded = decodeHtml(rawUrl);
  try {
    const parsed = new URL(decoded, "https://html.duckduckgo.com");
    const target = parsed.searchParams.get("uddg");
    const url = target ? decodeURIComponent(target) : decoded;
    return isPublicUrl(url) ? url : "";
  } catch {
    return "";
  }
}

async function searchPublicSources(query: string): Promise<Source[]> {
  const searchUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query.slice(0, 240))}`;
  const html = await fetchWithTimeout(searchUrl);
  const results: Source[] = [];
  const blocks = html.match(/<div class="result[\s\S]*?<\/div>\s*<\/div>/gi) || [];
  const candidates = blocks.length ? blocks : [html];

  for (const block of candidates) {
    const linkMatch = block.match(/<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i);
    if (!linkMatch) continue;
    const url = resolveSearchUrl(linkMatch[1]);
    if (!url || results.some(source => source.url === url)) continue;
    const title = decodeHtml(linkMatch[2]).slice(0, 180) || "Fonte consultada";
    const excerptMatch = block.match(/class="result__snippet"[^>]*>([\s\S]*?)<\/(?:a|div)>/i);
    const excerpt = excerptMatch ? decodeHtml(excerptMatch[1]).slice(0, 260) : "Resultado público encontrado para a consulta.";
    const domain = new URL(url).hostname.replace(/^www\./, "");
    results.push({ title, url, domain, excerpt });
    if (results.length === 3) break;
  }
  return results;
}

function fallbackClaim(input: string, articleTitle?: string) {
  const base = articleTitle && articleTitle !== "Notícia pública" ? articleTitle : input;
  const firstSentence = base.replace(/\s+/g, " ").split(/(?<=[.!?])\s+/)[0];
  return firstSentence.slice(0, 260).trim() || "A informação enviada pelo usuário";
}

function limitExplanation(value: string) {
  const paragraphs = value.split(/\n{2,}/).map(item => item.trim()).filter(Boolean).slice(0, 3);
  return (paragraphs.length ? paragraphs : [value.trim()]).join("\n\n").slice(0, 1500);
}

function parseModelJson(value: string) {
  const normalized = value.replace(/^```(?:json)?/i, "").replace(/```$/i, "").trim();
  const start = normalized.indexOf("{");
  const end = normalized.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("Resposta do modelo não é JSON");
  return JSON.parse(normalized.slice(start, end + 1)) as { claim?: string; classification?: string; explanation?: string };
}

async function classify(input: string, claim: string, sources: Source[], articleText: string) {
  if (sources.length === 0) {
    return {
      claim,
      classification: "⚪ NECESSITA DE ANÁLISE HUMANA" as const,
      explanation: "Não encontramos fontes públicas suficientes para comparar esta afirmação com segurança.\n\nUma análise humana deve consultar as fontes originais e considerar o contexto completo antes de concluir.",
    };
  }

  const sourceContext = sources.map((source, index) => `FONTE ${index + 1}\nTítulo: ${source.title}\nURL: ${source.url}\nTrecho: ${source.excerpt}`).join("\n\n");
  const prompt = `Você é o analista do MVP VERIFICA CIDADÃO. Avalie uma única afirmação factual com cuidado e linguagem simples. Use exclusivamente o texto enviado e os trechos das fontes abaixo. Escolha exatamente uma classificação permitida. Se a evidência for insuficiente ou ambígua, escolha ⚪ NECESSITA DE ANÁLISE HUMANA ou 🟠 SEM EVIDÊNCIAS SUFICIENTES. Nunca acuse pessoas, empresas, agentes públicos ou instituições de corrupção, fraude, crime ou irregularidade. Nunca transforme uma divergência em acusação: descreva apenas o que as fontes sustentam. A explicação deve ter no máximo três parágrafos curtos e mencionar o limite da consulta quando necessário.\n\nAFIRMAÇÃO SUGERIDA: ${claim}\n\nCONTEÚDO ENVIADO (pode ser notícia, texto ou URL): ${input.slice(0, 7000)}\n\nTEXTO EXTRAÍDO DA URL, SE HOUVER: ${articleText.slice(0, 5000)}\n\nFONTES CONSULTADAS:\n${sourceContext}`;

  try {
    const response = await invokeLLM({
      messages: [
        { role: "system", content: "Responda somente com JSON válido conforme o schema." },
        { role: "user", content: prompt },
      ],
      maxTokens: 650,
      responseFormat: { type: "json_schema", json_schema: ANALYSIS_SCHEMA },
    });
    const content = response.choices[0]?.message.content;
    const text = Array.isArray(content) ? content.filter(part => part.type === "text").map(part => part.text).join(" ") : content;
    const parsed = parseModelJson(text || "");
    const classification = CLASSIFICATIONS.includes(parsed.classification as (typeof CLASSIFICATIONS)[number]) ? parsed.classification as (typeof CLASSIFICATIONS)[number] : "⚪ NECESSITA DE ANÁLISE HUMANA";
    return {
      claim: (parsed.claim || claim).slice(0, 320),
      classification,
      explanation: limitExplanation(parsed.explanation || "As fontes foram consultadas, mas a resposta precisa de análise humana adicional."),
    };
  } catch (error) {
    console.error("Verification analysis failed:", error);
    return {
      claim,
      classification: "⚪ NECESSITA DE ANÁLISE HUMANA" as const,
      explanation: "As fontes foram encontradas, mas não foi possível concluir a comparação automatizada com segurança.\n\nConsulte os links originais e faça uma análise humana antes de compartilhar ou tomar decisões.",
    };
  }
}

export function registerVerifyRoute(app: Express) {
  app.post("/api/verify", async (req: Request, res: Response) => {
    const input = typeof req.body?.input === "string" ? req.body.input.trim() : "";
    if (input.length < 8) return res.status(400).json({ error: "Cole uma afirmação, notícia ou URL para começar a verificação." });
    if (input.length > 12000) return res.status(400).json({ error: "O conteúdo enviado é muito longo. Limite o texto a 12.000 caracteres." });

    const looksLikeUrl = /^https?:\/\//i.test(input);
    let articleText = "";
    let articleTitle = "";
    let originalSource: Source | null = null;

    if (looksLikeUrl) {
      if (!isPublicUrl(input)) return res.status(400).json({ error: "Use uma URL pública começando com http:// ou https://." });
      try {
        const html = await fetchWithTimeout(input);
        articleText = cleanText(html);
        articleTitle = titleFromHtml(html);
        originalSource = { title: articleTitle, url: input, domain: new URL(input).hostname.replace(/^www\./, ""), excerpt: articleText.slice(0, 260) };
      } catch {
        return res.status(400).json({ error: "Não foi possível acessar essa página aberta. Tente colar o texto da notícia." });
      }
    }

    const claim = fallbackClaim(input, articleTitle);
    const query = `${claim} ${articleTitle}`.slice(0, 240);
    let searchedSources: Source[] = [];
    try {
      searchedSources = await searchPublicSources(query);
    } catch (error) {
      console.error("Public source search failed:", error);
    }
    const sources = [originalSource, ...searchedSources].filter((source, index, list): source is Source => Boolean(source) && list.findIndex(item => item?.url === source?.url) === index).slice(0, 3);
    const analysis = await classify(input, claim, sources, articleText);
    return res.json({ ...analysis, sources, analyzedAt: new Date().toISOString() });
  });
}
